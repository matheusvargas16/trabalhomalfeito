package com.asdasd.asdasd.service

import com.asdasd.asdasd.model.Funcionario
import com.asdasd.asdasd.repository.FuncionarioRepository
import org.springframework.stereotype.Service

@Service
public class FuncionarioService(private val repository: FuncionarioRepository) {

    fun findAll(): List<Funcionario> = repository.findAll()

    fun findById(id: Long): Funcionario? = repository.findById(id).orElse(null)

    fun save(funcionario: Funcionario): Funcionario = repository.save(funcionario)

    fun update(id: Long, novoFuncionario: Funcionario): Funcionario {
        val funcionarioExistente = findById(id)
        return if (funcionarioExistente != null) {
            novoFuncionario.id = id
            save(novoFuncionario)
        } else {
            throw NoSuchElementException("Funcionário não encontrado com ID $id")
        }
    }

    fun delete(id: Long) {
        repository.deleteById(id)
    }
}