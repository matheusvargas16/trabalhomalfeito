package com.asdasd.asdasd.controller

import com.asdasd.asdasd.model.Funcionario
import com.asdasd.asdasd.service.FuncionarioService
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/funcionarios")
public class FuncionarioController(private val service: FuncionarioService) {

    @GetMapping
    fun getAllFuncionarios(): List<Funcionario> = service.findAll()

    @GetMapping("/{id}")
    fun getFuncionarioById(@PathVariable id: Long): Funcionario? = service.findById(id)

    @PostMapping
    fun createFuncionario(@RequestBody funcionario: Funcionario): Funcionario = service.save(funcionario)

    @PutMapping("/{id}")
    fun updateFuncionario(@PathVariable id: Long, @RequestBody novoFuncionario: Funcionario): Funcionario =
        service.update(id, novoFuncionario)

    @DeleteMapping("/{id}")
    fun deleteFuncionario(@PathVariable id: Long) = service.delete(id)
}