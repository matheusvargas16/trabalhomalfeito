package com.asdasd.asdasd.repository

import com.asdasd.asdasd.model.Funcionario
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
public interface FuncionarioRepository : JpaRepository<Funcionario, Long>